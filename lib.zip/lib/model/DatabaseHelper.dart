import 'dart:async';
import 'dart:io';

import 'package:connectivity/connectivity.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();

  factory DatabaseHelper() => _instance;

  static Database? _database;

  DatabaseHelper._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;

    _database = await initDatabase();
    return _database!;
  }

  Future<Database> initDatabase() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, 'main.db');
    return await openDatabase(path, version: 1,
        onCreate: (Database db, int version) async {
      await db.execute('''
          CREATE TABLE IF NOT EXISTS cropdata (
            farmerid INTEGER PRIMARY KEY,
            imagePath TEXT,
            cropType TEXT,
            cropAge TEXT,
            cropTemp TEXT,
            suggestion TEXT,
            confidence REAL,
            timestamp TEXT
          )
          ''');
    });
  }

  Future<int> insertData({
    required String imagePath,
    required String cropType,
    required String cropAge,
    required String cropTemp,
    required String suggestion,
    required double confidence,
    required String timestamp,

  }) async {
    Database db = await database;
    int id = await db.insert('cropdata', {
      'imagePath': imagePath,
      'cropType': cropType,
      'cropAge': cropAge,
      'cropTemp': cropTemp,
      'suggestion': suggestion,
      'confidence': confidence,
      'timestamp' : timestamp,
    });
    await _sendToFirebaseIfConnected();
    return id;
  }

  Future<List<Map<String, dynamic>>> getData() async {
    Database db = await database;
    return await db.query('cropdata');
  }

  Future<void> _sendToFirebaseIfConnected() async {
    var connectivityResult = await Connectivity().checkConnectivity();
    if (connectivityResult == ConnectivityResult.none) {
      print('No internet connection');
      return;
    }

    // Retrieve data from SQLite database
    Database db = await database;
    List<Map<String, dynamic>> result = await db.query('cropdata');

    // Upload data to Firebase
    await _uploadDataToFirebase(result);
  }

  Future<void> _uploadDataToFirebase(List<Map<String, dynamic>> data) async {
    // Upload data to Firebase Storage
    for (var row in data) {
      String imagePath = row['imagePath'];
      // Replace 'your_bucket' with your Firebase Storage bucket name
      Reference ref = FirebaseStorage.instance.ref().child('your_bucket').child(imagePath);
      File file = File(imagePath);
      await ref.putFile(file);
    }

    // Once data is successfully uploaded, delete it from local SQLite database
  //   await _deleteDataFromLocalDatabase();
  // }

  // Future<void> _deleteDataFromLocalDatabase() async {
  //   Database db = await database;
  //   await db.delete('cropdata');
  }
}
