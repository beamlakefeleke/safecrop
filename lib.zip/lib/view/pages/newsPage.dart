import 'package:flutter/material.dart';

class NewsPage extends StatelessWidget {
  const NewsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 128, 200, 85),
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 128, 200, 85),
      ),
      body: Column(
        children: [
          Container(
              child: Column(
            children: [
              Container(
                  child: Container(
                height: MediaQuery.of(context).size.height / 6,
                width: MediaQuery.of(context).size.width,
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image(
                        width: 70,
                        image: AssetImage(
                          "assets/a.png",
                        ),
                      ),
                      Text(
                        'Safe Crop',
                        style: TextStyle(
                          fontSize: 28,
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ]),
              )),
              Container(
                  child: Column(
                children: [
                  Container(
                      child: Container(
                    decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                            color: Colors.black26,
                            offset: Offset(-3, 5),
                            blurRadius: 22,
                            spreadRadius: 6)
                      ],
                      color: Color.fromARGB(255, 6, 47, 21),
                    ),
                    height: MediaQuery.of(context).size.height / 5,
                    width: MediaQuery.of(context).size.width,
                  )),
                ],
              )),
              
            ],
          )),Expanded(
                  child:ListView.builder(
              padding: EdgeInsets.only(left: 23, right: 23),
              itemCount: 7, // Replace with your desired item count
              itemBuilder: (context, index) {
                return Container(
                  margin: EdgeInsets.only(top: 10),
                  child: ListTile(
                    leading: Icon(
                      Icons.circle,
                      color: const Color.fromARGB(255, 0, 0, 0),
                    ), // Replace with your image path
                    title: Text(
                      'Title',
                      style: TextStyle(color: const Color.fromARGB(255, 0, 0, 0)),
                    ),
                    subtitle: Text('Description '),
                  ),
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                          color: const Color.fromARGB(66, 200, 183, 183),
                          offset: Offset(-3, 5),
                          blurRadius: 22,
                          spreadRadius: 6)
                    ],
                    color: Color.fromARGB(255, 255, 255, 255),
                  ),
                  height: MediaQuery.of(context).size.height / 11,
                  width: MediaQuery.of(context).size.height / 3,
                );
              },
            ), )
        ],
      ),
    );
  }
}
