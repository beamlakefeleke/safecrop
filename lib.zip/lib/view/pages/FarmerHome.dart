// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables

import 'package:flutter/material.dart';
import 'package:safe_crop/view/Pages/history.dart';
import 'package:safe_crop/view/pages/Detect.dart';
import 'package:safe_crop/view/pages/newsPage.dart';




class FarmerHomepage extends StatefulWidget {
  @override
  _FarmerHomepageState createState() => _FarmerHomepageState();
}

class _FarmerHomepageState extends State<FarmerHomepage> {
  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color.fromARGB(255, 128, 200, 85),
        body: Stack(children: [
          Container(
              child: Column(
            children: [
              Container(
                  child: Container(
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black26,
                        offset: Offset(-3, 5),
                        blurRadius: 22,
                        spreadRadius: 6)
                  ],
                  color: Colors.white,
                ),
                height: MediaQuery.of(context).size.height / 3,
                width: MediaQuery.of(context).size.width,
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image(
                        width: 70,
                        image: AssetImage(
                          "assets/c.png",
                        ),
                      ),
                      Text(
                        'Safe Crop',
                        style: TextStyle(
                          fontSize: 28,
                          color: Color.fromARGB(255, 6, 47, 21),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ]),
              )),
            ],
          )),
          Column(
            children: [
              Container(
                margin: EdgeInsets.only(
                  top: MediaQuery.of(context).size.height / 3.6,
                  left: 2,
                ),
                height: MediaQuery.of(context).size.height / 6,
                width: MediaQuery.of(context).size.height / 2,
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black26,
                        offset: Offset(-3, 5),
                        blurRadius: 22,
                        spreadRadius: 6)
                  ],
                  color: Color.fromARGB(255, 250, 250, 250),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ListTile(
                      leading: CircleAvatar(
                        child: Icon(Icons.person),
                        backgroundColor: Colors.white,
                      ),
                      title: Text(
                        'Yared Fentahun',
                        style: TextStyle(
                          fontSize: 20,
                          color: Color.fromARGB(255, 6, 47, 21),
                        ),
                      ),
                    ),
                    VerticalDivider(
                      // Added vertical divider
                      color: Color.fromARGB(255, 6, 47, 21),
                      thickness: 1,
                      width: 3,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Column(
                          children: [
                            Icon(
                              Icons.landscape,
                              size: 30,
                              color: Color.fromARGB(255, 6, 47, 21),
                            ),
                            Text(
                              '40 Sqrt',
                              style: TextStyle(
                                fontSize: 16,
                                color: Color.fromARGB(255, 6, 47, 21),
                              ),
                            ),
                          ],
                        ),
                        VerticalDivider(
                          // Added vertical divider
                          color: Color.fromARGB(255, 6, 47, 21),
                          thickness: 1,
                          width: 30,
                        ),
                        Column(
                          children: [
                            Icon(
                              Icons.location_on,
                              size: 30,
                              color: Color.fromARGB(255, 6, 47, 21),
                            ),
                            Text(
                              'Adama',
                              style: TextStyle(
                                fontSize: 16,
                                color: Color.fromARGB(255, 6, 47, 21),
                              ),
                            ),
                          ],
                        ),
                        VerticalDivider(
                          // Added vertical divider
                          color: Color.fromARGB(255, 6, 47, 21),
                          thickness: 10,
                          width: 30,
                        ),
                        Column(
                          children: [
                            Icon(
                              Icons.person,
                              size: 30,
                              color: Color.fromARGB(255, 6, 47, 21),
                            ),
                            Text(
                              'DR Bamlak',
                              style: TextStyle(
                                fontSize: 16,
                                color: Color.fromARGB(255, 6, 47, 21),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 30,
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Detect()),
                  );
                },
                child: Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Image(
                        image: AssetImage(
                          "assets/d.png",
                        ),
                      ),
                      Text(
                        'detect disease',
                        style: TextStyle(fontSize: 20),
                      ),
                      Icon(
                        Icons.arrow_forward_outlined,
                        size: 30,
                      )
                    ],
                  ),
                  height: 47,
                  width: MediaQuery.of(context).size.width / 1.2,
                  decoration: BoxDecoration(boxShadow: [
                    BoxShadow(
                        color: Colors.black26,
                        offset: Offset(0, 0),
                        blurRadius: 22,
                        spreadRadius: 6),
                  ], color: Colors.white),
                ),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height / 33,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => CropHistoryPage()),
                      );
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width / 3.5,
                      height: MediaQuery.of(context).size.height / 7,
                      decoration: BoxDecoration(boxShadow: [
                        BoxShadow(
                            color: Colors.black26,
                            offset: Offset(0, 0),
                            blurRadius: 22,
                            spreadRadius: 6),
                      ], color: Color.fromARGB(255, 128, 200, 85)),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.article,
                            size: 50,
                            color: Colors.white,
                          ),
                          SizedBox(height: 10),
                          Text(
                            'News',
                            style: TextStyle(
                              fontSize: 20,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => NewsPage()),
                      );
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width / 3.5,
                      height: MediaQuery.of(context).size.height / 7,
                      decoration: BoxDecoration(boxShadow: [
                        BoxShadow(
                            color: Colors.black26,
                            offset: Offset(0, 0),
                            blurRadius: 22,
                            spreadRadius: 6),
                      ], color: Color.fromARGB(255, 128, 200, 85)),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.article,
                            size: 50,
                            color: Colors.white,
                          ),
                          SizedBox(height: 10),
                          Text(
                            'News',
                            style: TextStyle(
                              fontSize: 20,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height / 33,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => CropHistoryPage()),
                      );
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width / 3.5,
                      height: MediaQuery.of(context).size.height / 7,
                      decoration: BoxDecoration(boxShadow: [
                        BoxShadow(
                            color: Colors.black26,
                            offset: Offset(0, 0),
                            blurRadius: 22,
                            spreadRadius: 6),
                      ], color: Color.fromARGB(255, 128, 200, 85)),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.article,
                            size: 50,
                            color: Colors.white,
                          ),
                          SizedBox(height: 10),
                          Text(
                            'News',
                            style: TextStyle(
                              fontSize: 20,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => CropHistoryPage()),
                      );
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width / 3.5,
                      height: MediaQuery.of(context).size.height / 7,
                      decoration: BoxDecoration(boxShadow: [
                        BoxShadow(
                            color: Colors.black26,
                            offset: Offset(0, 0),
                            blurRadius: 22,
                            spreadRadius: 6),
                      ], color: Color.fromARGB(255, 128, 200, 85)),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.add_task_rounded,
                            size: 50,
                            color: Colors.white,
                          ),
                          SizedBox(height: 10),
                          Text(
                            'History',
                            style: TextStyle(
                              fontSize: 20,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              )
            ],
          )
        ]));
  }
}
