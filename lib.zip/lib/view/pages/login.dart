import 'package:flutter/material.dart';

import 'FarmerHome.dart';
import 'signup.dart';

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Color.fromARGB(255, 128, 200, 85),
      body: Expanded(
        child: Column(
          children: [
            Container(
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                      color: Colors.black26,
                      offset: Offset(-3, 5),
                      blurRadius: 22,
                      spreadRadius: 6)
                ],
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(120),
                ),
                color: Colors.white,
              ),
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Well Come to',
                      style: TextStyle(
                        fontSize: 28,
                        color: Color.fromARGB(255, 6, 47, 21),
                      ),
                    ),
                    SizedBox(
                      height: 22,
                    ),
                    Container(
                      padding: EdgeInsets.only(
                        right: 1,
                      ),
                      child: Image(
                        width: 70,
                        image: AssetImage(
                          "assets/c.png",
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 11,
                    ),
                    Text(
                      'Safe Crop',
                      style: TextStyle(
                        fontSize: 28,
                        color: Color.fromARGB(255, 6, 47, 21),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ]),
              height: MediaQuery.of(context).size.height / 2.6,
              width: MediaQuery.of(context).size.width,
            ),
            Expanded(
                child: Container(
              child: Column(
                children: [
                  SizedBox(
                    height: 20,
                  ),
                  Container(
                    child: Text(
                      'login',
                      style: TextStyle(
                        fontSize: 28,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
              
                  Container(
                    decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                            color: Colors.black26,
                            offset: Offset(-3, 5),
                            blurRadius: 22,
                            spreadRadius: 1)
                      ],
                    ),
                    width: MediaQuery.of(context).size.width / 1.1,
                    height: 55,
                    child: TextField(
                      decoration: InputDecoration(
                          prefixIcon: Icon(Icons.person, color: Colors.grey),
                          fillColor: Colors.white,
                          filled: true,
                          hintText: 'Name'),
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Container(
                    height: 55,
                    decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                            color: Colors.black26,
                            offset: Offset(-3, 5),
                            blurRadius: 22,
                            spreadRadius: 6)
                      ],
                    ),
                    width: MediaQuery.of(context).size.width / 1.1,
                    child: TextField(
                      decoration: InputDecoration(
                          prefixIcon: Icon(Icons.phone, color: Colors.grey),
                          fillColor: Colors.white,
                          filled: true,
                          hintText: 'phone'),
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Container(
                    height: 55,
                    decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                            color: Colors.black26,
                            offset: Offset(-3, 5),
                            blurRadius: 22,
                            spreadRadius: 6)
                      ],
                    ),
                    width: MediaQuery.of(context).size.width / 1.1,
                    child: TextField(
                      decoration: InputDecoration(
                          prefixIcon: Icon(Icons.vpn_key, color: Colors.grey),
                          fillColor: Colors.white,
                          filled: true,
                          hintText: 'password'),
                    ),
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  GestureDetector(
                    onTap: () => {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => FarmerHomepage()),
                      )
                    },
                    child: Container(
                      margin: EdgeInsets.only(left: 220),
                      child: Center(
                        child: Text(
                          'login',
                          style: TextStyle(
                            fontSize: 27.0,
                            color: Color.fromARGB(255, 6, 47, 21),
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      width: 100,
                      height: 45,
                      decoration: BoxDecoration(
                        boxShadow: [
                          BoxShadow(
                              color: Colors.black26,
                              offset: Offset(-3, 5),
                              blurRadius: 22,
                              spreadRadius: 6)
                        ],
                        color: Colors.white,
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: 70,
                      ),
                      Text("Don't have an account? "),
                      TextButton(
                        onPressed: () {
                          // Sign up button action
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => SignUpPage()),
                          );
                        },
                        child: Text(
                          "Sign Up",
                          style: TextStyle(
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ))
          ],
        ),
      ),
    );
  }
}
