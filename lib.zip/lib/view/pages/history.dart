import 'dart:async';

import 'package:flutter/material.dart';

import '../../model/DatabaseHelper.dart';


class CropHistoryPage extends StatefulWidget {
  const CropHistoryPage({Key? key}) : super(key: key);

  @override
  State<CropHistoryPage> createState() => _CropHistoryPageState();
}

class _CropHistoryPageState extends State<CropHistoryPage> {
  late Future<List<Map<String, dynamic>>> _cropData;

  @override
  void initState() {
    super.initState();
    _cropData = _getDataFromDatabase();
  }

  Future<List<Map<String, dynamic>>> _getDataFromDatabase() async {
    DatabaseHelper dbHelper = DatabaseHelper();
    return dbHelper.getData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.menu),
          onPressed: () {
            // Navigate to the menu screen
            // Replace `MenuScreen` with the actual screen/widget you want to navigate to
            // Navigator.push(
            //   context,
            //   MaterialPageRoute(builder: (context) => MenuScreen()),
            // );
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () {
              // Navigate back to the previous screen
              Navigator.pop(context);
            },
          ),
        ],
        title: const Text('History'),
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            height: 100,
            padding: const EdgeInsets.only(
              left: 40,
              top: 30,
              bottom: 0,
              right: 40,
            ),
            child: Column(
              children: [
                Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset(
                        'assets/d.png', // Replace 'your_image.png' with your image asset path
                        width: 40, // Adjust the width of the image as needed
                        height: 40, // Adjust the height of the image as needed
                      ),
                      const SizedBox(width: 10), // Add some space between the image and text
                      const Text(
                        'Scan History',
                        style: TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20.0),
              ],
            ),
          ),
          Expanded(
            child: Container(
              width: double.infinity,
              decoration: const BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    offset: Offset(-3, 5),
                    blurRadius: 70,
                    spreadRadius: 6,
                  ),
                ],
                color: Color.fromARGB(255, 128, 200, 85),
              ),
              padding: const EdgeInsets.only(
                top: 30,
                left: 30,
                bottom: 50,
                right: 30,
              ),
              child: FutureBuilder<List<Map<String, dynamic>>>(
                future: _cropData,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  } else if (snapshot.hasError) {
                    return Center(child: Text('Error: ${snapshot.error}'));
                  } else {
                    List<Map<String, dynamic>> data = snapshot.data ?? [];
                    return ListView.builder(
                      itemCount: data.length,
                      itemBuilder: (context, index) {
                        Map<String, dynamic> item = data[index];
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8.0),
                          child: ElevatedButton(
                            onPressed: () {
                              // Navigate to the detail page
                               Navigator.of(context).push(
                        PageRouteBuilder(
                          opaque: false, // Make the detail page non-opaque
                          pageBuilder: (BuildContext context, _, __) {
                            return DetailPage(data:item);
                          },
                        ),
                      );
                            },
                            style: ElevatedButton.styleFrom(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                              elevation: 4,
                              primary: Colors.white,
                              // padding: EdgeInsets.all(3),
                              shadowColor: Colors.black26,
                            ),
                            child: ListTile(
                              title: Text(item['cropType']),
                              subtitle: Text(item['timestamp']),
                            ),
                          ),
                        );
                      },
                    );
                  }
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class DetailPage extends StatelessWidget {
  final Map<String, dynamic> data;

  const DetailPage({Key? key, required this.data}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
     backgroundColor: Colors.transparent,
      body: Center(
        child: Card(
          elevation: 6,
          child: Container(
            padding: const EdgeInsets.all(20),
            width: double.infinity,
            height: 300,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('Crop Type: ${data['cropType']}'),
                Text('Crop Age: ${data['cropAge']}'),
                Text('Crop Temp: ${data['cropTemp']}'),
                Text('Suggestion: ${data['suggestion']}'),
                Text('Confidence: ${data['confidence']}'),
                Text('Timestamp: ${data['timestamp']}'),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context); // Close the detail page
                  },
                  child: const Text('Close'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
