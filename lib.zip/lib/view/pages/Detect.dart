import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'package:tflite_v2/tflite_v2.dart';

import 'dart:developer' as devtools;

import '../../model/DatabaseHelper.dart';
import 'CropResult.dart';

class Detect extends StatefulWidget {
  const Detect({super.key});

  @override
  State<Detect> createState() => _DetectState();
}

class _DetectState extends State<Detect> {
  final dbHelper = DatabaseHelper();
  final ImagePicker _picker = ImagePicker();
  File? filePath;
  String _croptype = 'wheat'; // Default selection
  String _cropage = '1 to 6 month';
  String _croptemp = 'warm';
  String label = '';
  double confidence = 0.0;
  List<String> suggestions = [];
  DateTime now = DateTime.now();
  String timestamp = '';

  Future<void> _tfLteInit() async {
    String? res = await Tflite.loadModel(
      model: "assets/Maizedetectionv2.tflite",
      labels: "assets/labels.txt",
      numThreads: 1, // defaults to 1
      isAsset:
          true, // defaults to true, set to false to load resources outside assets
      useGpuDelegate:
          false, // defaults to false, set to true to use GPU delegate
    );
  }
  void chooseImages() async {
final ImagePicker picker = ImagePicker();
    // Pick an image.
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);

    if (image == null) return;

    var imageMap = File(image.path);

    setState(() {
      filePath = imageMap;
    });

    var recognitions = await Tflite.runModelOnImage(
      path: image.path, // required
      imageMean: 0.0, // defaults to 117.0
      imageStd: 255.0, // defaults to 1.0
      numResults: 2, // defaults to 5
      threshold: 0.2, // defaults to 0.1
      asynch: true, // defaults to true
    );

    if (recognitions == null) {
      devtools.log("recognitions is Null");
      return;
    }

    setState(() {
      double confidence = recognitions[0]['confidence'] * 100;
      if (confidence >= 90) {
        label = recognitions[0]['label'].toString();
        suggestions = getLabelSuggestions(label);
        this.confidence = confidence;
      } else {
        label = "Invalid image. Please send a clear image.";
        suggestions = [];
        this.confidence = 0.0;
      }
    });
  }

  void captureImages() async {
final ImagePicker picker = ImagePicker();
    // Pick an image.
    final XFile? image = await picker.pickImage(source: ImageSource.camera);

    if (image == null) return;

    var imageMap = File(image.path);

    setState(() {
      filePath = imageMap;
    });

    var recognitions = await Tflite.runModelOnImage(
      path: image.path, // required
      imageMean: 0.0, // defaults to 117.0
      imageStd: 255.0, // defaults to 1.0
      numResults: 2, // defaults to 5
      threshold: 0.2, // defaults to 0.1
      asynch: true, // defaults to true
    );

    if (recognitions == null) {
      devtools.log("recognitions is Null");
      return;
    }

    setState(() {
      double confidence = recognitions[0]['confidence'] * 100;
      if (confidence >= 90) {
        label = recognitions[0]['label'].toString();
        suggestions = getLabelSuggestions(label);
        this.confidence = confidence;
      } else {
        label = "Invalid image. Please send a clear image.";
        suggestions = [];
        this.confidence = confidence;
      }
    });
  }

  @override
  void dispose() {
    super.dispose();
    Tflite.close();
  }

  @override
  void initState() {
    super.initState();
    _tfLteInit();
  }
  // void submitImage() {
  //   // Implement your logic for submitting the image here
  //   if (_image != null) {
  //     // If an image is selected, you can proceed with submitting it
  //     // For example, you can upload it to a server or process it in some way
  //     print('Submitting image: ${_image!.path}');
  //   } else {
  //     // If no image is selected, you can show a message to the user
  //     print('No image selected');
  //   }
  // }

  List<String> getLabelSuggestions(String label) {
    switch (label) {
      case 'Maize Rust':
        return ['Consider applying fungicide.'];
      case 'Maize Leaf Spot':
        return ['Use fungicide and improve ventilation.'];
      case 'Maize Healthy':
        return ['Keep monitoring for any changes.'];
      case 'Maize Leaf Blight':
        return ['Use fungicide and remove infected leaves.'];
      default:
        return [];
    }
  }

    void submitData() async {
    if (confidence >= 90) {
      await dbHelper.insertData(
        imagePath: filePath?.path ?? '',
        cropType: _croptype,
        cropAge: _cropage,
        cropTemp: _croptemp,
        suggestion: label,
        confidence: confidence,
        timestamp : now.toString(),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.menu),
          onPressed: () {
            // Navigate to the menu screen
            // Replace `MenuScreen` with the actual screen/widget you want to navigate to
            // Navigator.push(
            //   context,
            //   MaterialPageRoute(builder: (context) => MenuScreen()),
            // );
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () {
              // Navigate back to the previous screen
              Navigator.pop(context);
            },
          ),
        ],
        title: const Text('Detect'),
      ),
      body: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        child: Column(
          children: [
            Container(
              width: double.infinity, // Match parent width
              height: 400,
              // padding: const EdgeInsets.all(40.0), // Add padding
              padding: const EdgeInsets.only(
                  left: 40, bottom: 0, right: 40),
              child: Column(
                // Inner column for content
                children: [
                  // Image container
                  Container(
                          height: 280,
                          width: 280,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            image: const DecorationImage(
                              image: AssetImage('assets/upload.jpg'),
                            ),
                          ),
                          child: filePath == null
                              ? const Text('')
                              : Image.file(
                                  filePath!,
                                  fit: BoxFit.fill,
                                ),
                        ),

                  const SizedBox(
                      height: 20.0), // Spacing between image and text

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      ElevatedButton(
                        onPressed: () {
                          chooseImages();
                        },
                        child: const Text("Choose Image"),
                      ),
                      ElevatedButton(
                        onPressed: () {
                          captureImages();
                        },
                        child: const Text("Capture Image"),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              height: 450,
              width: double.infinity,
              decoration: const BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26, // Adjust shadow color as needed
                    offset: Offset(
                      -3,
                      5,
                    ), // Modify x and y offsets for shadow position
                    blurRadius: 22, // Control shadow blur
                    spreadRadius: 6, // Adjust shadow spread
                  ),
                ],
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(120), // Curved bottom left corner
                ),
                color: Color.fromARGB(
                    255, 128, 200, 85), // Set container background color
              ),
              padding: const EdgeInsets.only(
                  top: 70, left: 50, bottom: 50, right: 50),
              child: Column(
                children: [
                  const SizedBox(
                    height: 20,
                  ),
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10.0),
                      boxShadow: const [
                        BoxShadow(
                          color: Colors.black26,
                          offset: Offset(-3, 5),
                          blurRadius: 22,
                          spreadRadius: 6,
                        ),
                      ],
                    ),
                    child: DropdownButton<String>(
                      value: _croptype,
                      items: [
                        DropdownMenuItem<String>(
                          value: 'wheat',
                          child: Row(
                            children: <Widget>[
                              Icon(Icons
                                  .pest_control_outlined), // Add icon before text
                              SizedBox(
                                  width:
                                      8), // Add some space between icon and text
                              Text('wheat'),
                            ],
                          ),
                        ),
                        DropdownMenuItem<String>(
                          value: 'Maize',
                          child: Row(
                            children: <Widget>[
                              Icon(Icons
                                  .pest_control_outlined), // Add icon before text
                              SizedBox(
                                  width:
                                      8), // Add some space between icon and text
                              Text('Maize'),
                            ],
                          ),
                        ),
                        DropdownMenuItem<String>(
                          value: 'Barly',
                          child: Row(
                            children: <Widget>[
                              Icon(Icons
                                  .pest_control_outlined), // Add icon before text
                              SizedBox(
                                  width:
                                      8), // Add some space between icon and text
                              Text('Barly'),
                            ],
                          ),
                        ),
                      ],
                      onChanged: (String? type) {
                        setState(() {
                          _croptype = type ?? ''; // Set default if null
                        });
                      },
                      dropdownColor:
                          Colors.white, // Set dropdown background color
                      icon: Icon(Icons.arrow_drop_down), // Add dropdown icon
                      elevation: 8, // Add elevation
                      style: TextStyle(color: Colors.black), // Set text color
                      underline: Container(), // Remove underline
                      isExpanded: true, // Expand dropdown to fit content
                    ),
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10.0),
                      boxShadow: const [
                        BoxShadow(
                          color: Colors.black26,
                          offset: Offset(-3, 5),
                          blurRadius: 22,
                          spreadRadius: 6,
                        ),
                      ],
                    ),
                    child: DropdownButton<String>(
                      value: _cropage,
                      items: [
                        DropdownMenuItem<String>(
                          value: '1 to 6 month',
                          child: Row(
                            children: <Widget>[
                              Icon(Icons
                                  .pest_control_outlined), // Add icon before text
                              SizedBox(
                                  width:
                                      8), // Add some space between icon and text
                              Text('1 to 6 month'),
                            ],
                          ),
                        ),
                        DropdownMenuItem<String>(
                          value: '7 to 12 month',
                          child: Row(
                            children: <Widget>[
                              Icon(Icons
                                  .pest_control_outlined), // Add icon before text
                              SizedBox(
                                  width:
                                      8), // Add some space between icon and text
                              Text('7 to 12 month'),
                            ],
                          ),
                        ),
                        DropdownMenuItem<String>(
                          value: '13 to 18 month',
                          child: Row(
                            children: <Widget>[
                              Icon(Icons
                                  .pest_control_outlined), // Add icon before text
                              SizedBox(
                                  width:
                                      8), // Add some space between icon and text
                              Text('13 to 18 month'),
                            ],
                          ),
                        ),
                      ],
                      onChanged: (String? age) {
                        setState(() {
                          _cropage = age ?? ''; // Set default if null
                        });
                      },
                      dropdownColor:
                          Colors.white, // Set dropdown background color
                      icon: Icon(Icons.arrow_drop_down), // Add dropdown icon
                      elevation: 8, // Add elevation
                      style: TextStyle(color: Colors.black), // Set text color
                      underline: Container(), // Remove underline
                      isExpanded: true, // Expand dropdown to fit content
                    ),
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10.0),
                      boxShadow: const [
                        BoxShadow(
                          color: Colors.black26,
                          offset: Offset(-3, 5),
                          blurRadius: 22,
                          spreadRadius: 6,
                        ),
                      ],
                    ),
                    child: DropdownButton<String>(
                      value: _croptemp,
                      items: [
                        DropdownMenuItem<String>(
                          value: 'warm',
                          child: Row(
                            children: <Widget>[
                              Icon(Icons
                                  .pest_control_outlined), // Add icon before text
                              SizedBox(
                                  width:
                                      8), // Add some space between icon and text
                              Text('warm'),
                            ],
                          ),
                        ),
                        DropdownMenuItem<String>(
                          value: 'rainy',
                          child: Row(
                            children: <Widget>[
                              Icon(Icons
                                  .pest_control_outlined), // Add icon before text
                              SizedBox(
                                  width:
                                      8), // Add some space between icon and text
                              Text('rainy'),
                            ],
                          ),
                        ),
                        DropdownMenuItem<String>(
                          value: 'windy',
                          child: Row(
                            children: <Widget>[
                              Icon(Icons
                                  .pest_control_outlined), // Add icon before text
                              SizedBox(
                                  width:
                                      8), // Add some space between icon and text
                              Text('windy'),
                            ],
                          ),
                        ),
                      ],
                      onChanged: (String? temp) {
                        setState(() {
                          _croptemp = temp ?? ''; // Set default if null
                        });
                      },
                      dropdownColor:
                          Colors.white, // Set dropdown background color
                      icon: Icon(Icons.arrow_drop_down), // Add dropdown icon
                      elevation: 8, // Add elevation
                      style: TextStyle(color: Colors.black), // Set text color
                      underline: Container(), // Remove underline
                      isExpanded: true, // Expand dropdown to fit content
                    ),
                  ),
                  const SizedBox(
                    height: 50,
                  ),
                  // ElevatedButton(
                  //   onPressed: () {
                  //     submitImage();
                  //   },
                  //   child: const Text("Submit"),
                  // ),
                  Container(
                    // Make the button width fill the available space
                    child: ElevatedButton(
                      onPressed: () {
                        submitData();
                        if (confidence >= 90) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => Result(
          image: filePath,
          cropType: _croptype,
          cropAge: _cropage,
          cropTemp: _croptemp,
          suggestion: label, // Pass the suggestion to the Result page
          confidence: confidence,
          timestamp: now.toString(),
        ),
      ),
    );
  } else {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Error'),
          content: const Text('The image is valid. Please recapture the image.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }
                      },
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(
                              0), // Adjust border radius as needed
                        ),
                      ),
                      child: const Text(
                        "Detect",
                        style: TextStyle(
                            fontSize: 20, // Adjust the font size as needed
                            fontWeight: FontWeight.bold, // Add bold font weight
                            color: Colors.black),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
